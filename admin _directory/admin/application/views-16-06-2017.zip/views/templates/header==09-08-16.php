<head>
    <meta charset="utf-8" />
    <title>Battleme</title>
    <meta name="description" content="app, web app, responsive, admin dashboard, admin, flat, flat ui, ui kit, off screen nav" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <link rel="stylesheet" href="<?php echo base_url();?>public/css/app.v1.css" type="text/css" />
    <link rel="stylesheet" href="<?php echo base_url();?>public/js/chosen/chosen.css" type="text/css" />
    <link rel="stylesheet" href="<?php echo base_url();?>public/css/style.css" type="text/css" />
   
    <!--[if lt IE 9]> <script src="/layouts/battle/js/ie/html5shiv.js"></script>  <![endif]-->
	<script>
	var base_url = "<?php echo base_url(); ?>";
	</script>
	<script src="<?php echo base_url('public/js/jquery.min.js'); ?>"></script>
</head>
